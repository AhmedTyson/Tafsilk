# Tafsilk
Tafsilk is a digital platform that connects users with trusted local tailors. It makes tailoring services simple, transparent, and accessible from discovery to booking and review.

/* demo dataset - list of tailors */
var TAFSILK_TAILORS = [
  {id:1, name: 'ورشة 1', rating: 3.8, price_from: 793 },
  {id:2, name: 'ورشة 2', rating: 3.8, price_from: 652 },
  {id:3, name: 'ورشة 3', rating: 3.5, price_from: 603 },
  {id:4, name: 'ورشة 4', rating: 4.4, price_from: 209 },
  {id:5, name: 'ورشة 5', rating: 3.8, price_from: 480 },
  {id:6, name: 'ورشة 6', rating: 3.8, price_from: 796 },
  {id:7, name: 'ورشة 7', rating: 3.6, price_from: 486 },
  {id:8, name: 'ورشة 8', rating: 3.8, price_from: 280 },
  {id:9, name: 'ورشة 9', rating: 4.9, price_from: 448 },
  {id:10, name: 'ورشة 10', rating: 3.8, price_from: 799 },
  {id:11, name: 'ورشة 11', rating: 4.4, price_from: 677 },
  {id:12, name: 'ورشة 12', rating: 4.2, price_from: 638 },
  {id:13, name: 'ورشة 13', rating: 4.1, price_from: 693 },
  {id:14, name: 'ورشة 14', rating: 3.6, price_from: 266 },
  {id:15, name: 'ورشة 15', rating: 5.0, price_from: 459 },
  {id:16, name: 'ورشة 16', rating: 4.8, price_from: 196 },
  {id:17, name: 'ورشة 17', rating: 4.3, price_from: 712 },
  {id:18, name: 'ورشة 18', rating: 4.5, price_from: 400 },
  {id:19, name: 'ورشة 19', rating: 4.8, price_from: 252 },
  {id:20, name: 'ورشة 20', rating: 4.9, price_from: 680 },
  {id:21, name: 'ورشة 21', rating: 4.2, price_from: 311 },
  {id:22, name: 'ورشة 22', rating: 4.8, price_from: 333 },
  {id:23, name: 'ورشة 23', rating: 4.2, price_from: 640 },
  {id:24, name: 'ورشة 24', rating: 3.6, price_from: 680 },
  {id:25, name: 'ورشة 25', rating: 4.5, price_from: 177 },
  {id:26, name: 'ورشة 26', rating: 3.6, price_from: 158 },
  {id:27, name: 'ورشة 27', rating: 3.6, price_from: 800 },
  {id:28, name: 'ورشة 28', rating: 3.6, price_from: 754 },
  {id:29, name: 'ورشة 29', rating: 4.2, price_from: 746 },
  {id:30, name: 'ورشة 30', rating: 4.7, price_from: 614 },
  {id:31, name: 'ورشة 31', rating: 3.5, price_from: 669 },
  {id:32, name: 'ورشة 32', rating: 5.0, price_from: 678 },
  {id:33, name: 'ورشة 33', rating: 4.0, price_from: 681 },
  {id:34, name: 'ورشة 34', rating: 4.2, price_from: 189 },
  {id:35, name: 'ورشة 35', rating: 4.7, price_from: 435 },
  {id:36, name: 'ورشة 36', rating: 4.2, price_from: 731 },
  {id:37, name: 'ورشة 37', rating: 5.0, price_from: 708 },
  {id:38, name: 'ورشة 38', rating: 3.9, price_from: 421 },
  {id:39, name: 'ورشة 39', rating: 4.2, price_from: 755 },
  {id:40, name: 'ورشة 40', rating: 4.7, price_from: 446 },
  {id:41, name: 'ورشة 41', rating: 3.7, price_from: 194 },
  {id:42, name: 'ورشة 42', rating: 4.6, price_from: 215 },
  {id:43, name: 'ورشة 43', rating: 3.7, price_from: 561 },
  {id:44, name: 'ورشة 44', rating: 4.5, price_from: 451 },
  {id:45, name: 'ورشة 45', rating: 3.9, price_from: 514 },
  {id:46, name: 'ورشة 46', rating: 4.5, price_from: 406 },
  {id:47, name: 'ورشة 47', rating: 4.3, price_from: 542 },
  {id:48, name: 'ورشة 48', rating: 4.6, price_from: 754 },
  {id:49, name: 'ورشة 49', rating: 4.1, price_from: 702 },
  {id:50, name: 'ورشة 50', rating: 4.1, price_from: 169 },
  {id:51, name: 'ورشة 51', rating: 3.9, price_from: 629 },
  {id:52, name: 'ورشة 52', rating: 4.1, price_from: 727 },
  {id:53, name: 'ورشة 53', rating: 4.7, price_from: 311 },
  {id:54, name: 'ورشة 54', rating: 4.4, price_from: 669 },
  {id:55, name: 'ورشة 55', rating: 3.8, price_from: 578 },
  {id:56, name: 'ورشة 56', rating: 4.7, price_from: 216 },
  {id:57, name: 'ورشة 57', rating: 3.6, price_from: 479 },
  {id:58, name: 'ورشة 58', rating: 4.4, price_from: 342 },
  {id:59, name: 'ورشة 59', rating: 4.0, price_from: 573 },
  {id:60, name: 'ورشة 60', rating: 3.8, price_from: 548 },
];

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

// filler line

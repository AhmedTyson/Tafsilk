
Tafsilk Static v2
------------------
This package is a self-contained static website demo for the Tafsilk platform.
- No frameworks required (vanilla HTML/CSS/JS)
- Three.js used via CDN for background visuals
- GSAP used via CDN for animations (optional, referenced in HTML)
- Features: Landing, Register, Tailor profile, Dashboard, FAQ accordion, Lightbox, Animated counters, Search demo.

To run locally: open index.html in a modern browser (or serve via simple HTTP server)


Tafsilk — Optimized deliverable
===============================

What I changed:
- Replaced heavy animated background (three.js + gsap) with a lightweight CSS gradient background to reduce CPU and improve performance.
- Added a search bar (client-side) that filters cards on the page.
- Added a video modal component (YouTube embed). Look for elements with class "howto-video-btn" and data-video="<YOUTUBE_ID>" to trigger it.
- Added Google and Facebook **UI** buttons in the header. These are placeholders and require real OAuth credentials for working sign-in flows.
- Added a language toggle (EN/ع) which reads translations from translations.json and updates elements with data-i18n attributes.
- Enforced vertical-only scrolling (overflow-x:hidden) and fixed gallery sizing for tailors (class .tailor-gallery).
- Optimized local images (resized and recompressed).
- Enabled lazy-loading and async decoding for images.

How to configure social login (optional):
- Google and Facebook buttons are UI-only. You must create OAuth clients on each platform and implement server-side flow or use client-side SDKs and replace the placeholder handlers in js/ui.js.

Files added/modified:
- index.html (updated header, search, modal)
- css/style.css (appended performance + components styles)
- js/ui.js (new enhanced UI code)
- translations.json (Arabic + English)
- README.txt (this file)

Notes:
- This is a front-end static update and does not include backend auth. For production-level social login and performance comparable to major CDNs, consider deploying on modern hosting with CDN, using image CDNs, and enabling compression (gzip/brotli) on the server.
- I preserved your navigation design as requested.



Final assistant pass:
- Nav redesigned to be minimal & professional (hamburger + CTA preserved).
- Left-side drawer added (handle on left edge), filled with many items.
- Removed background animations across all pages (background.js emptied and script includes removed).
- Color palette adjusted for clearer contrast; use CSS variables at top of css/style.css.
- Galleries now link to external curated images (images_links.json).

Images (Unsplash search pages used as sources):
- Tailor measuring client: https://unsplash.com/s/photos/tailor-shop (Unsplash)
- Tailor at sewing machine: https://unsplash.com/photos/1Wk2PiW1UIE (Unsplash)
- Workshop interior: https://unsplash.com/s/photos/tailor-shop (Unsplash)
- Tailor suits shop: https://unsplash.com/s/photos/tailor-shop (Unsplash)
- Elderly tailor: https://unsplash.com/photos/dSBbkJm0NdQ (Unsplash)
- Hand-sewing tailor: https://unsplash.com/photos/8WRvNhmwnuk (Unsplash)
- Sewing machine closeup: https://unsplash.com/s/photos/sewing-machine (Unsplash)
- Designer sketching: https://unsplash.com/photos/AetkaHejwns (Unsplash)

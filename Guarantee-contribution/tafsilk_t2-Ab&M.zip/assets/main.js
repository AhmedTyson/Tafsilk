
// Touch-friendly menu and modal behavior
document.addEventListener('DOMContentLoaded', function(){
  var menuBtn = document.querySelector('.menu-btn');
  var quickMenu = document.querySelector('.quick-menu');
  if(menuBtn && quickMenu){
    menuBtn.addEventListener('click', function(){
      var expanded = this.getAttribute('aria-expanded') === 'true';
      this.setAttribute('aria-expanded', !expanded);
      quickMenu.style.display = expanded ? (window.innerWidth>=800?'flex':'none') : 'flex';
      quickMenu.setAttribute('aria-hidden', expanded);
    });
  }
  // Make all elements with class nav-btn behave as buttons (keyboard+touch accessible)
  document.querySelectorAll('.nav-btn').forEach(function(b){
    b.setAttribute('role','button');
    b.addEventListener('keydown', function(e){ if(e.key==='Enter' || e.key===' ') b.click(); });
  });

  // Modal for how-to video
  var howBtn = document.getElementById('howto-btn');
  var modal = document.getElementById('howto-modal');
  var close = document.querySelector('.close-modal');
  var frame = document.getElementById('howto-frame');
  if(howBtn && modal){
    howBtn.addEventListener('click', openModal);
  }
  if(close) close.addEventListener('click', closeModal);
  function openModal(e){
    modal.style.display='flex';
    modal.setAttribute('aria-hidden','false');
    // autoplay by appending autoplay param
    if(frame && frame.src.indexOf('autoplay=1')===-1){
      frame.src = frame.src + (frame.src.indexOf('?')===-1 ? '?' : '&') + 'autoplay=1';
    }
  }
  function closeModal(){
    modal.style.display='none';
    modal.setAttribute('aria-hidden','true');
    // stop playback by removing src
    if(frame){
      var src = frame.src.split('?')[0];
      frame.src = src;
    }
  }

  // Simple contact form handler (no backend) - show thank you
  var form = document.getElementById('contact-form');
  if(form){
    form.addEventListener('submit', function(e){
      e.preventDefault();
      alert('شكراً! تم استلام رسالتك (تجريبي).');
      form.reset();
    });
  }

  // Make product cards' images lazy
  document.querySelectorAll('img').forEach(function(img){
    if(!img.hasAttribute('loading')) img.setAttribute('loading','lazy');
  });

  // Make all links that look like buttons actually keyboard-focusable
  document.querySelectorAll('a').forEach(function(a){
    if(!a.hasAttribute('tabindex')) a.setAttribute('tabindex','0');
  });
});
